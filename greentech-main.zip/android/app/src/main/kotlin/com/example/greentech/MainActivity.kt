package com.example.greentech

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
